#ifndef _TIMER_H_
#define _TIMER_H_




extern void Timer0_Init (void);	
extern void Interrupt_Init (void);
#endif


