#ifndef _DELAY_H_
#define _DELAY_H_






void delay(void)	;
void delay_ms( INT16U cnt)	;
#endif


